from datetime import datetime
def year_context(r):
    return {'year':datetime.now().year}
